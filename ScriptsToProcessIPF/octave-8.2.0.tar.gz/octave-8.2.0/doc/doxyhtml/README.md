This directory contains Doxygen documentation for Octave's source code.
It is not created by default.  To generate the Doxygen documentation use

    make doxyhtml

Doxygen documentation can be helpful for developers of Octave, but is not
needed by users of Octave.  In addition, the documentation requires
approximately 3 GB of storage space.  For these reasons it is not maintained
under version control nor distributed in tarballs.
