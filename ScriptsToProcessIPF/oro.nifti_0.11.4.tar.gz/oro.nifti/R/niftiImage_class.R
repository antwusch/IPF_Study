#' "niftiImage" class
#'
#' @name niftiImage-class
#' @aliases niftiImage
#' @family niftiImage
#' 
#' @import methods
#'
#' @exportClass niftiImage
setOldClass("niftiImage")

#' "internalImage" class
#'
#' @name internalImage-class
#' @aliases internalImage
#' @family internalImage
#' 
#' @exportClass internalImage
setOldClass("internalImage")

