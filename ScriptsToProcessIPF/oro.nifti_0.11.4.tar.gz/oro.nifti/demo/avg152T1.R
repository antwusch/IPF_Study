avg152T1 <- readANALYZE(file.path(system.file("anlz", package="oro.nifti"),
                                  "avg152T1"))
image(avg152T1)
orthographic(avg152T1)
