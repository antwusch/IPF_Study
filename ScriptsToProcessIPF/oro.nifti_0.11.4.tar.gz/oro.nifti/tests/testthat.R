library(testthat)
library(oro.nifti)

test_check("oro.nifti")
